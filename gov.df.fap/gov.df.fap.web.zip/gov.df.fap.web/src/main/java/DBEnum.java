public enum DBEnum {
  ORACLE, ORACLERAC, DM, DB2, MYSQL, SQLSERVER;
}
