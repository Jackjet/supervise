public abstract interface IFaspAfertReflashEventListener {
  public abstract void afertReflash();
}
