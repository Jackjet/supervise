public class FaspModule {
  public static final String[] FASP_MODULES = { "WF", "FSB", "PA", "BC", "COMMONPA", "BUSCOMMON", "BUSPA", "FW", "CA",
    "DIC", "SEC", "MU", "GL", "RU", "FI", "BUSFW", "CL" };

  public static final String[] DEF_MODULES = { "FW", "CA", "DIC", "SEC", "FSB", "MU", "FI", "CL" };
}