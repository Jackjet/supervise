package interf;

public abstract interface IHearbeatListener {
  public abstract void start(String paramString1, String paramString2);

  public abstract void stop(String paramString1, String paramString2);
}
